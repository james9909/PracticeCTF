<?php
error_reporting(0);

include('class.php');

if (isset($_POST['user']) && isset($_POST['pass'])) {
	$user_object = new User($_POST['user'], $_POST['pass']);
	setcookie('user_object', urlencode(serialize($user_object)));
}

header('Location: /19-poig/');

?>