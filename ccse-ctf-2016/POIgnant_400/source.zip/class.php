<?php

/* A simple user class. */
class User {
	private $username;
	private $password;
	
	/* Constructor for creating new user objects */
	function __construct($username, $password) {
		$this->username = $username; // Set the object's private variable username.
		$this->password = $password; // Set the object's prviate variable password.
	}
	
	/* Returns a greeting string with the username */
	function greet() {
		return 'Hello ' . $this->username . '!';
	}
}

/* It's not like you could ever get here. Muhahahaha. */
class ReadFlag {
	private $file;
	
	function __construct($file) {
		$this->file = $file;
	}
	
	/* It's not like you could call this. Muhahahaha. */
	function greet() {
		if ($this->file === 'protected/flag.txt') {
			$handle = fopen($this->file, 'r');
			if ($handle) {
				$line = fgets($handle);
				fclose($handle);
				return 'Flag: ' . $line;
			}
		}
		
		return 'You are a failure.'; // Because you are for not being able to get the flag.
	}
}

?>