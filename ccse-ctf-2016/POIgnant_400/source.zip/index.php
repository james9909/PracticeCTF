<?php
error_reporting(0);

include('class.php');

if (isset($_COOKIE['user_object'])) {
	try {
		$user_object = unserialize(urldecode($_COOKIE['user_object']));
		$greeting = $user_object->greet();
	} catch (Exception $e) {
		$greeting = $e;
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<link rel="stylesheet" href="style.css" type="text/css" />
		<link href='http://fonts.googleapis.com/css?family=Ubuntu+Mono' rel='stylesheet' type='text/css'>
		<title>Web Exploitation</title>
	</head>
	
	<body>
		<p><? echo $greeting ?> My apologies but we currently cannot save users. - D1rect0r Troll</p>
	</body>
</html>

<!-- source.zip -->
<?php
} else {
?>
<!DOCTYPE HTML>
<html>
	<head>
		<link rel="stylesheet" href="style.css" type="text/css" />
		<link href='http://fonts.googleapis.com/css?family=Ubuntu+Mono' rel='stylesheet' type='text/css'>
		<title>Web Exploitation</title>
	</head>
	
	<body>
		<p>Create an account! - D1rect0r Troll</p>
	
		<form action="create.php" method="post">
			<p>Username: <input type="text" name="user"></p>
			<p>Password: <input type="password" name="pass"></p>
			<button type="submit" style="margin-top:20px;">Submit</button>
		</form>
	</body>
</html>
<?php
}
?>
